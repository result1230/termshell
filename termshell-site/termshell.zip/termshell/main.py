import os
import time
import colorama
import json

version = "0.0.1"
status = "demo"

with open("date.json", "r") as f:
	data = json.load(f)

stored_code = data.get("code")

while True:
	pin_code = input("Enter a code: ")

	if pin_code == stored_code:
		print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Good!" + colorama.Style.RESET_ALL)
		break
	else:
		print(colorama.Fore.RED + colorama.Style.BRIGHT + "Wrong!" + colorama.Style.RESET_ALL)

def main():
	global data
	while True:
		command = input("> ")
		
		if command == "quit":
			exit()
		elif command == "changecode":
			new_code = input("Enter a new password: ")
			data["code"] = new_code
			
			with open("date.json", "w") as f:
				json.dump(data, f)
				print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Good!" + colorama.Style.RESET_ALL)
		elif command == "info":
			print("Information about TermShell")
			print(f"Version: {version}")
			print(f"Status: {status}")
		else:
			os.system(command)

if __name__ == "__main__":
	main()
