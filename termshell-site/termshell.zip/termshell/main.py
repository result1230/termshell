import os
import time
import colorama
import json
import readline

os.system("clear")

version = "0.0.2"
status = "demo"

folder = os.path.basename(os.getcwd())

with open("date.json", "r") as f:
	data = json.load(f)

stored_code = data.get("code")

while True:
	pin_code = input("Enter a code: ")

	if pin_code == stored_code:
		print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Good!" + colorama.Style.RESET_ALL)
		os.system("clear")
		break
	else:
		print(colorama.Fore.RED + colorama.Style.BRIGHT + "Wrong!" + colorama.Style.RESET_ALL)

def main():
	global data
	global folder
	while True:
		command = input(f"{folder} > ")
		
		if command == "quit":
			os.kill(os.getppid(), 9)
		elif command == "changecode":
			new_code = input("Enter a new password: ")
			data["code"] = new_code
			
			with open("date.json", "w") as f:
				json.dump(data, f)
				print(colorama.Fore.GREEN + colorama.Style.BRIGHT + "Good!" + colorama.Style.RESET_ALL)
		elif command == "info":
			print("Information about TermShell")
			print(f"Version: {version}")
			print(f"Status: {status}")
		elif command.startswith("cd "):
			try:
				os.chdir(command[3:])
				folder = os.path.basename(os.getcwd())
			except FileNotFoundError:
				print("Some folder is no in directory")
		elif command == "pwd":
			print(os.getcwd())
		elif command == "cd":
			os.chdir(os.path.expanduser("~"))
			folder = os.path.basename(os.getcwd())
		else:
			os.system(command)

if __name__ == "__main__":
	main()
